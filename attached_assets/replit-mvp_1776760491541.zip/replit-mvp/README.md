# Care + Transport + Jobs — Replit MVP

A minimal FastAPI backend with a static HTML/JS frontend to demo core flows:
- Create a Care Request (auto-creates a Shift) and assign a worker
- Get Transport Quotes and book a mock accessible trip
- List Jobs and submit a Job Application

## Quick start on Replit
1. Create a new **Python** Repl.
2. Upload all files from this folder (or import the ZIP).
3. Replit should install `replit.nix` and `requirements.txt` automatically.
4. Press **Run**. The server starts at `https://<your-repl>.replit.app/` and shows the demo UI.

If it doesn’t auto-run, open the Shell and run:
```bash
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

## API Endpoints
- `GET /health`
- `POST /care/requests`
- `POST /care/shifts/{shift_id}/assign` (body: `{ "worker_name": "..." }`)
- `POST /transport/trips/quote` (mocked options)
- `POST /transport/trips`
- `GET /jobs?q=&remote_ok=`
- `POST /jobs/{job_id}/applications`

## Notes
- Data is in-memory and resets on restart.
- This is an MVP starter meant for rapid iteration and demos.
- Next step: connect to real transport/job/provider integrations and add auth.
