async function jget(url) {
  const r = await fetch(url);
  return r.json();
}
async function jpost(url, data) {
  const r = await fetch(url, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
  });
  return r.json();
}

// Health
document.getElementById('btnHealth').addEventListener('click', async () => {
  const out = document.getElementById('outHealth');
  out.textContent = '...';
  const res = await jget('/health');
  out.textContent = JSON.stringify(res, null, 2);
});

// Care create
document.getElementById('careForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const payload = {
    participant_name: fd.get('participant_name'),
    needs: [],
    start_at: new Date(fd.get('start_at')).toISOString(),
    end_at: new Date(fd.get('end_at')).toISOString(),
    tasks: (fd.get('tasks') || '').split(',').map(t => t.trim()).filter(Boolean)
  };
  const res = await jpost('/care/requests', payload);
  document.getElementById('outCare').textContent = JSON.stringify(res, null, 2);
  // Fill shift id for convenience
  const shiftId = res.shift?.id;
  if (shiftId) document.querySelector('#assignForm input[name=shift_id]').value = shiftId;
});

// Assign shift
document.getElementById('assignForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const shift_id = fd.get('shift_id');
  const res = await jpost(`/care/shifts/${shift_id}/assign`, { worker_name: fd.get('worker_name')});
  document.getElementById('outAssign').textContent = JSON.stringify(res, null, 2);
});

// Transport quote
document.getElementById('quoteForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const payload = {
    pickup: { lat: parseFloat(fd.get('plat')), lng: parseFloat(fd.get('plng')) },
    dropoff: { lat: parseFloat(fd.get('dlat')), lng: parseFloat(fd.get('dlng')) },
    pickup_window_minutes: parseInt(fd.get('window')),
    access_needs: ['wheelchair'], // demo default
    mobility_aids: ['power_chair'],
    companions: 0
  };
  const res = await jpost('/transport/trips/quote', payload);
  const options = document.getElementById('options');
  options.innerHTML = '';
  res.forEach((opt, idx) => {
    const div = document.createElement('div');
    div.className = 'opt';
    div.innerHTML = `<strong>${opt.provider_name}</strong> — ${opt.mode}<br>ETA: ${opt.eta_minutes}m • A$${opt.price_estimate_aud}<br><button data-i="${idx}">Book this</button>`;
    div.querySelector('button').addEventListener('click', async () => {
      const book = await jpost('/transport/trips', { option: opt, notes: 'Demo booking' });
      document.getElementById('outTrip').textContent = JSON.stringify(book, null, 2);
    });
    options.appendChild(div);
  });
});

// Jobs list
document.getElementById('btnJobs').addEventListener('click', async () => {
  const res = await jget('/jobs');
  const wrap = document.getElementById('jobs');
  wrap.innerHTML = '';
  res.jobs.forEach(j => {
    const div = document.createElement('div');
    div.className = 'job';
    div.innerHTML = `<strong>${j.title}</strong> — ${j.location} • ${j.pay_range}<br>ID: <code>${j.id}</code>`;
    wrap.appendChild(div);
  });
});

// Apply
document.getElementById('applyForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const job_id = fd.get('job_id');
  const payload = {
    applicant_name: fd.get('name'),
    contact_email: fd.get('email'),
    notes: fd.get('notes') || ''
  };
  const res = await jpost(`/jobs/${job_id}/applications`, payload);
  document.getElementById('outApp').textContent = JSON.stringify(res, null, 2);
});
