
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from typing import List, Optional, Dict
from datetime import datetime
import uuid

app = FastAPI(title="Care + Transport + Jobs — MVP", version="0.1.0")

# Allow the bundled static frontend and local testing origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory stores (MVP only)
DB = {
    "users": {},
    "care_requests": {},
    "care_shifts": {},
    "trips": {},
    "jobs": {},
    "applications": {},
}

# Seed a few jobs
seed_jobs = [
    {
        "id": "job_" + uuid.uuid4().hex[:8],
        "title": "Receptionist (Accessible Workplace)",
        "type": "part-time",
        "location": "Sydney CBD",
        "remote_ok": False,
        "onsite_accessibility": {"ramp": True, "accessible_bathroom": True},
        "pay_range": "A$30–35/hr",
        "status": "open",
        "adjustments_offered": ["Flexible hours", "Screen reader-friendly tools"]
    },
    {
        "id": "job_" + uuid.uuid4().hex[:8],
        "title": "Customer Support (Remote)",
        "type": "casual",
        "location": "Remote (AU)",
        "remote_ok": True,
        "onsite_accessibility": {},
        "pay_range": "A$28–32/hr",
        "status": "open",
        "adjustments_offered": ["Remote work stipend", "Captioned meetings"]
    }
]
for j in seed_jobs:
    DB["jobs"][j["id"]] = j

# ----------------------- Models -----------------------
class AccessibilityNeeds(BaseModel):
    wheelchair: Optional[bool] = False
    ramp: Optional[bool] = False
    driver_assistance: Optional[bool] = False

class GeoPoint(BaseModel):
    lat: float
    lng: float

class TripQuoteRequest(BaseModel):
    pickup: GeoPoint
    dropoff: GeoPoint
    pickup_window_minutes: int = Field(ge=0, le=180, default=20)
    access_needs: List[str] = []
    mobility_aids: List[str] = []
    companions: int = 0

class TripOption(BaseModel):
    provider_name: str
    mode: str
    eta_minutes: int
    price_estimate_aud: float
    vehicle_features: List[str]

class TripCreateRequest(BaseModel):
    option: TripOption
    notes: Optional[str] = None

class CareRequest(BaseModel):
    participant_name: str
    needs: List[str] = []
    start_at: datetime
    end_at: datetime
    tasks: List[str] = []

class AssignShiftRequest(BaseModel):
    worker_name: str

class JobFilters(BaseModel):
    q: Optional[str] = None
    remote_ok: Optional[bool] = None

class ApplicationCreate(BaseModel):
    applicant_name: str
    contact_email: str
    notes: Optional[str] = None

# ----------------------- Routes -----------------------

@app.get("/health")
def health():
    return {"status": "ok", "time": datetime.utcnow().isoformat() + "Z"}

@app.post("/care/requests")
def create_care_request(payload: CareRequest):
    id_ = "care_" + uuid.uuid4().hex[:8]
    data = payload.model_dump()
    data["id"] = id_
    DB["care_requests"][id_] = data
    # naive shift creation
    shift_id = "shift_" + uuid.uuid4().hex[:8]
    shift = {
        "id": shift_id,
        "care_request_id": id_,
        "participant_name": payload.participant_name,
        "start_at": payload.start_at.isoformat(),
        "end_at": payload.end_at.isoformat(),
        "status": "unassigned",
        "tasks": payload.tasks,
        "ndis_line_item": None,
        "worker_name": None,
    }
    DB["care_shifts"][shift_id] = shift
    return {"care_request": data, "shift": shift}

@app.post("/care/shifts/{shift_id}/assign")
def assign_shift(shift_id: str, payload: AssignShiftRequest):
    shift = DB["care_shifts"].get(shift_id)
    if not shift:
        raise HTTPException(404, "Shift not found")
    shift["worker_name"] = payload.worker_name
    shift["status"] = "assigned"
    return {"shift": shift}

@app.post("/transport/trips/quote", response_model=List[TripOption])
def trip_quote(payload: TripQuoteRequest):
    # Mock quotes; in production call GTFS/partners here
    base_price = 18.0
    distance_km = 5.0  # mocked
    needs_multiplier = 1.0 + (0.1 * len(payload.access_needs))
    options = [
        TripOption(
            provider_name="Community Transport NSW",
            mode="WAT",
            eta_minutes=15,
            price_estimate_aud=round(base_price + distance_km * 2.5 * needs_multiplier, 2),
            vehicle_features=["wheelchair_ramp", "tie_downs"]
        ),
        TripOption(
            provider_name="Sydney WAT Co-op",
            mode="WAT",
            eta_minutes=9,
            price_estimate_aud=round(base_price + distance_km * 3.0 * needs_multiplier, 2),
            vehicle_features=["wheelchair_ramp"]
        )
    ]
    return options

@app.post("/transport/trips")
def create_trip(payload: TripCreateRequest):
    id_ = "trip_" + uuid.uuid4().hex[:8]
    trip = {
        "id": id_,
        "provider_name": payload.option.provider_name,
        "mode": payload.option.mode,
        "eta_minutes": payload.option.eta_minutes,
        "price_estimate_aud": payload.option.price_estimate_aud,
        "vehicle_features": payload.option.vehicle_features,
        "notes": payload.notes,
        "status": "booked"
    }
    DB["trips"][id_] = trip
    return {"trip": trip}

@app.get("/jobs")
def list_jobs(q: Optional[str] = None, remote_ok: Optional[bool] = None):
    jobs = list(DB["jobs"].values())
    if q:
        ql = q.lower()
        jobs = [j for j in jobs if ql in j["title"].lower() or ql in j["location"].lower()]
    if remote_ok is not None:
        jobs = [j for j in jobs if bool(j.get("remote_ok")) == remote_ok]
    return {"jobs": jobs}

@app.post("/jobs/{job_id}/applications")
def apply_job(job_id: str, payload: ApplicationCreate):
    job = DB["jobs"].get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    app_id = "app_" + uuid.uuid4().hex[:8]
    application = {
        "id": app_id,
        "job_id": job_id,
        "applicant_name": payload.applicant_name,
        "contact_email": payload.contact_email,
        "notes": payload.notes,
        "status": "submitted",
        "submitted_at": datetime.utcnow().isoformat() + "Z",
    }
    DB["applications"][app_id] = application
    return {"application": application, "job": job}

# Serve the static demo UI
app.mount("/", StaticFiles(directory="static", html=True), name="static")
